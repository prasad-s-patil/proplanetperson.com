<?php
// footer.php
?>

<footer>
    <p>&copy; 2024 Pro Planet Person. All rights reserved.</p>
    <p>
        Follow us on 
        <a href="https://twitter.com" target="_blank">Twitter</a>, 
        <a href="https://instagram.com" target="_blank">Instagram</a>, and 
        <a href="https://facebook.com" target="_blank">Facebook</a>.
    </p>
</footer>
</body>
</html>
